/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student;

/**
 *
 * @author ADMIN
 */
public class TemplateQuestion {

    // DO NOT MODIFY THIS FILE - KHÔNG SỬA NỘI DUNG CỦA FILE NÀY - HOẶC BẠN SẼ BỊ RỚT
    
    public Cabinet cabinet = new Cabinet();

    public void insert() {
        cabinet.add();
    }

    public void update() {
        cabinet.update();
    }

    public void search() {
        cabinet.search();
    }

    public void remove() {
        cabinet.remove();
    }

    public void sort() {
        cabinet.sort();
    }

}
