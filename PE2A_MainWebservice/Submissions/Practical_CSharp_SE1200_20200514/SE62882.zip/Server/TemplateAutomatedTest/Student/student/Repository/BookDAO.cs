﻿using CSharpTemplate.Practical.student.DBUtil;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTemplate.Practical.student.Repository
{
    class BookDAO
    {

        public static SqlDataAdapter LoadAllBook()
        {
            var getConnection = Connection.GetConnection();
            if (getConnection.State == ConnectionState.Closed)
            {
                getConnection.Open();
            }
            var data = new SqlDataAdapter("Select * from Book", getConnection);

            return data;
        }

        public static SqlDataAdapter SearchByName(String name)
        {
            if (name.Length > 0)
            {
                var getConnection = Connection.GetConnection();
                if (getConnection.State == ConnectionState.Closed)
                {
                    getConnection.Open();
                }
                SqlDataAdapter data = new SqlDataAdapter("Select * from Book where Name like @name", getConnection);
                data.SelectCommand.Parameters.AddWithValue("@name", "%" + name + "%");
                var dataSet = new DataSet();
                data.Fill(dataSet);
                int count = dataSet.Tables[0].Rows.Count;
                Console.WriteLine(count + "");
                return data;
            }
            else
            {
                return LoadAllBook();
            }
        }

        public static Boolean InsertBook(int id,String name, String price)
        {
            var getConnection = Connection.GetConnection();
            if (getConnection.State == ConnectionState.Closed)
            {
                getConnection.Open();
            }
            SqlCommand sql = new SqlCommand("Insert into Book values(@id,@name,@price)", getConnection);
            sql.Parameters.AddWithValue("@id", id);
            sql.Parameters.AddWithValue("@name", name);
            sql.Parameters.AddWithValue("@price", price);
            int afflected = sql.ExecuteNonQuery();
            if (afflected > 0)
            {
                return true;
            }
            return false;
        }

        public static Boolean UpdateBook(int id, String name, String price)
        {
            var getConnection = Connection.GetConnection();
            if (getConnection.State == ConnectionState.Closed)
            {
                getConnection.Open();
            }
            SqlCommand sql = new SqlCommand("Update Book set Name = @name,Price = @price where Id = @id", getConnection);
            sql.Parameters.AddWithValue("@name", name);
            sql.Parameters.AddWithValue("@price", price);
            sql.Parameters.AddWithValue("@id", id);

            int afflected = sql.ExecuteNonQuery();
            if (afflected > 0)
            {
                return true;
            }
            return false;
        }

        public static Boolean DeleteBook(int id)
        {
            var getConnection = Connection.GetConnection();
            if (getConnection.State == ConnectionState.Closed)
            {
                getConnection.Open();
            }
            SqlCommand sql = new SqlCommand("Delete from Book where Id = @id", getConnection);
            sql.Parameters.AddWithValue("@Id", id);
            int afflected = sql.ExecuteNonQuery();
            if (afflected > 0)
            {
                return true;
            }
            return false;
        }
        public static void CleanDatabase()
        {
            var getConnection = Connection.GetConnection();
            if (getConnection.State == ConnectionState.Closed)
            {
                getConnection.Open();
            }
            SqlCommand sql = new SqlCommand("Delete from Book", getConnection);
            sql.ExecuteNonQuery();
        }
    }
}
