﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTemplate.Practical.student.Model
{
    class Admin
    {
        public String Id { get; set; }
        public String Password { get; set; }
        public String Fullname { get; set; }
        public Boolean IsAdmin { get; set; }
    }
}
