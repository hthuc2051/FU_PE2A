/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tblweapon;

import com.practicalexam.student.connection.DBUtilities;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NamingException;

/**
 *
 * @author nhocc
 */
public class WeaponDAO {

    private List<WeaponDTO> listWeapon;

    public List<WeaponDTO> getListWeapon() {
        return listWeapon;
    }

    public int showAll() throws NamingException, SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String sql = "SELECT amourId, description, classification, defense, timeOfCreate, status "
                        + "FROM tbl_Weapon";
                ps = con.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    String amourId = rs.getString("amourId");
                    String description = rs.getString("description");
                    String classification = rs.getString("classification");
                    Timestamp defense = rs.getTimestamp("defense");
                    String timeOfCreate = rs.getString("timeOfCreate");
                    boolean status = rs.getBoolean("status");
                    WeaponDTO dto = new WeaponDTO(amourId, description, classification, defense, timeOfCreate, status);
                    if (listWeapon == null) {
                        listWeapon = new ArrayList<>();
                    }
                    listWeapon.add(dto);
                }
                if (listWeapon != null) {
                    return listWeapon.size();
                } else {
                    return 0;
                }
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return -1;
    }

    public boolean deleteAmour(String amourId) throws NamingException, SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean checkDeleted = false;

        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String sql = "DELETE tbl_Weapon WHERE amourId = ?";
                ps = con.prepareStatement(sql);
                ps.setString(1, amourId);
                checkDeleted = ps.executeUpdate() > 0;
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return checkDeleted;
    }
}
