/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tbluser;

import com.practicalexam.student.connection.DBUtilities;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author nhocc
 */
public class UserDAO {

    private String fullName;

    public String getFullName() {
        return fullName;
    }

    public boolean checkLogin(String username, String password) throws NamingException, SQLException, ClassNotFoundException {
        boolean check = false;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String sql = "SELECT fullName "
                        + "FROM tbl_User "
                        + "WHERE userId = ? AND password = ? AND boss = ?";
                ps = con.prepareStatement(sql);
                ps.setString(1, username);
                ps.setString(2, password);
                ps.setBoolean(3, true);
                rs = ps.executeQuery();
                if (rs.next()) {
                    fullName = rs.getString("fullName");
                    check = true;
                }
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return check;
    }
}
