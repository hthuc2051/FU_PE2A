/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tblweapon;

import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author nhocc
 */
public class WeaponDTO {

    private String amourId;
    private String description;
    private String classification;
    private Timestamp defense;
    private String timeOfCreate;
    private boolean status;

    public WeaponDTO() {
    }

    public WeaponDTO(String amourId, String description, String classification, Timestamp defense, String timeOfCreate, boolean status) {
        this.amourId = amourId;
        this.description = description;
        this.classification = classification;
        this.defense = defense;
        this.timeOfCreate = timeOfCreate;
        this.status = status;
    }

    public String getAmourId() {
        return amourId;
    }

    public void setAmourId(String amourId) {
        this.amourId = amourId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public Timestamp getDefense() {
        return defense;
    }

    public void setDefense(Timestamp defense) {
        this.defense = defense;
    }

    public String getTimeOfCreate() {
        return timeOfCreate;
    }

    public void setTimeOfCreate(String timeOfCreate) {
        this.timeOfCreate = timeOfCreate;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

}
